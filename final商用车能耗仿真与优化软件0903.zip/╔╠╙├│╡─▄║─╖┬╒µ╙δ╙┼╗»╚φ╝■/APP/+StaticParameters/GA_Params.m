GA_Stastic_Params=struct;
GA_Stastic_Params.NIND=100;
GA_Stastic_Params.MAXGEN=50;
GA_Stastic_Params.NVAR=3;
GA_Stastic_Params.GGAP=0.9;
GA_Stastic_Params.PRECI=10;
