clear all;
clc
