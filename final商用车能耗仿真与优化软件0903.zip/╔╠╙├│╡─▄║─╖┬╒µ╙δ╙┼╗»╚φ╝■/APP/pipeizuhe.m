%% 计算筛选的组合的DP

% 挑出选的组合
Match_selected = Dynamic_Match_rank(Rank2Eco_double);
