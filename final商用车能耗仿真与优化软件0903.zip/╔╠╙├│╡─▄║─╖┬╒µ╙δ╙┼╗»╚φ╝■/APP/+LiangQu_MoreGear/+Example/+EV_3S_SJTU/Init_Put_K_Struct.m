function InPut_K = Init_Put_K_Struct()
    InPut_K.T_m_K_Grid = [];
    InPut_K.W_m_K_Grid = [];
    InPut_K.SOC_K_Grid = [];
    InPut_K.SOC_K_1_Grid = [];
    InPut_K.G_K_Grid = [];
    InPut_K.G_K_1_Grid = [];
    InPut_K.P_em_K_Grid = [];
    InPut_K.Pb_K_Grid = [];
    InPut_K.J_K_1_Grid = [];
    InPut_K.M_K_1_Grid = [];
    InPut_K.M_K_Grid = [];
    InPut_K.Fuel_K_1_Grid = []; 
end