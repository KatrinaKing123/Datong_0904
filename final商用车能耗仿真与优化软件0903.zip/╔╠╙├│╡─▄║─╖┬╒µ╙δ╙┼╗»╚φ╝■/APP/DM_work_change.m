%% FCS dp计算时切换工作路径

cd('F:\项目-doing\电动汽车能耗计算\软件开发\项目内容\part3匹配设计\参数匹配软件设计\3月31日代码更新\App补DMdynamicCalandPlot_NeedDPbatt\NEVs_DP_TJY');

%% 运行DP的m文件
Example.FCEV_2S_SJTU.FCEV_2S_SJTU

%% 换回来

cd('F:\项目-doing\电动汽车能耗计算\软件开发\项目内容\part3匹配设计\参数匹配软件设计\3月31日代码更新\App补DMdynamicCalandPlot_NeedDPbatt');